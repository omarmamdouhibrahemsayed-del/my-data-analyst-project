"""Menu-driven command-line interface."""

from __future__ import annotations

import argparse
import sys
from dataclasses import replace
from datetime import datetime, timedelta
from typing import Callable, Dict, List, Optional, Sequence, Tuple, Type, TypeVar

from .demo import load_demo_data
from .errors import FoodShareError, NotFoundError, StorageError
from .models import Allocation, Charity, DonorType, FoodCategory, FoodItem, Location
from .parsing import (
    parse_expiry,
    parse_index_list,
    parse_int,
    parse_location,
    parse_positive_float,
)
from .service import Coordinator
from .storage import DataStore

T = TypeVar("T")
DEFAULT_DATA_FILE = "foodshare_data.json"


# --------------------------------------------------------------------------- #
# Formatting helpers
# --------------------------------------------------------------------------- #
def format_table(headers: Sequence[str], rows: Sequence[Sequence[object]]) -> str:
    """Render rows as a simple fixed-width text table."""
    str_rows = [[str(c) for c in row] for row in rows]
    widths = [len(h) for h in headers]
    for row in str_rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))
    fmt = lambda cells: "  ".join(c.ljust(w) for c, w in zip(cells, widths)).rstrip()
    lines = [fmt(headers), "  ".join("-" * w for w in widths)]
    lines.extend(fmt(r) for r in str_rows)
    return "\n".join(lines)


def format_timedelta(delta: timedelta) -> str:
    total_minutes = int(delta.total_seconds() // 60)
    if total_minutes <= 0:
        return "expired"
    hours, minutes = divmod(total_minutes, 60)
    return f"{hours}h {minutes:02d}m" if hours else f"{minutes}m"


def format_dt(dt: datetime) -> str:
    return dt.astimezone().strftime("%Y-%m-%d %H:%M")


def _label(member: object) -> str:
    return str(getattr(member, "value", member)).replace("_", " ").title()


# --------------------------------------------------------------------------- #
# Prompting (injectable I/O so the CLI can be tested without a terminal)
# --------------------------------------------------------------------------- #
class Prompter:
    """Validated, re-prompting input helper."""

    def __init__(
        self,
        input_fn: Callable[[str], str] = input,
        output_fn: Callable[[str], None] = print,
    ) -> None:
        self._input = input_fn
        self.say = output_fn

    def text(self, prompt: str, required: bool = True) -> str:
        while True:
            raw = self._input(f"{prompt}: ").strip()
            if raw or not required:
                return raw
            self.say("  ! This field is required.")

    def ask(self, prompt: str, parser: Callable[[str], T], default: Optional[object] = None) -> T:
        """Prompt until ``parser`` accepts the input (blank uses ``default``)."""
        suffix = f" [{default}]" if default is not None else ""
        while True:
            raw = self._input(f"{prompt}{suffix}: ").strip()
            if not raw and default is not None:
                raw = str(default)
            try:
                return parser(raw)
            except ValueError as exc:  # ValidationError is a ValueError
                self.say(f"  ! {exc}")

    def choose(self, prompt: str, options: Sequence[T], label: Callable[[T], str]) -> T:
        for index, option in enumerate(options, 1):
            self.say(f"  {index}. {label(option)}")
        index = self.ask(prompt, lambda s: parse_int(s, 1, len(options)))
        return options[index - 1]

    def choose_enum(self, prompt: str, enum_cls: Type[T]) -> T:
        return self.choose(prompt, list(enum_cls), _label)  # type: ignore[call-overload]


# --------------------------------------------------------------------------- #
# Application
# --------------------------------------------------------------------------- #
class App:
    """Interactive menu bound to a :class:`Coordinator`."""

    def __init__(self, coordinator: Coordinator, prompter: Optional[Prompter] = None) -> None:
        self.coord = coordinator
        self.store = coordinator.store
        self.p = prompter or Prompter()
        self._actions: Dict[str, Tuple[str, Callable[[], None]]] = {
            "1": ("Register as a donor", self.register_donor),
            "2": ("Post surplus food", self.post_food),
            "3": ("Register as a charity / recipient", self.register_charity),
            "4": ("View available food", self.view_food),
            "5": ("View charities", self.view_charities),
            "6": ("Run matching algorithm", self.run_matching),
            "7": ("View distribution log", self.view_log),
            "8": ("Update allocation status (complete / cancel)", self.update_allocation),
            "9": ("Update a charity's current need", self.update_need),
            "10": ("Load demo data", self.load_demo),
        }

    # ---- main loop ------------------------------------------------------- #
    def run(self) -> int:
        self.p.say("\n=== Smart Food Waste & Donation Coordinator ===")
        while True:
            self._print_menu()
            try:
                choice = self.p.text("Select an option")
                if choice == "0":
                    self.p.say("Goodbye - thank you for helping reduce food waste!")
                    return 0
                action = self._actions.get(choice)
                if action is None:
                    self.p.say("  ! Invalid option, please choose from the menu.")
                    continue
                action[1]()
            except (EOFError, KeyboardInterrupt):
                self.p.say("\nGoodbye!")
                return 0
            except FoodShareError as exc:
                self.p.say(f"  ! Error: {exc}")

    def _print_menu(self) -> None:
        self.p.say("\n--- Main menu ---")
        for key, (title, _) in self._actions.items():
            self.p.say(f"  {key:>2}. {title}")
        self.p.say("   0. Exit")

    # ---- helpers --------------------------------------------------------- #
    def _ask_location(self, prompt: str) -> Location:
        loc = self.p.ask(prompt, parse_location)
        address = self.p.text("Address / landmark (optional)", required=False)
        return replace(loc, label=address)

    def _donor_name(self, donor_id: str) -> str:
        try:
            return self.store.get_donor(donor_id).name
        except NotFoundError:
            return donor_id

    def _allocation_row(self, a: Allocation) -> List[object]:
        item = self.store.get_item(a.item_id)
        charity = self.store.get_charity(a.charity_id)
        return [
            a.id, item.name, a.quantity, self._donor_name(item.donor_id), charity.name,
            f"{a.distance_km:.1f}", f"{a.score:.2f}", format_dt(a.pickup_by), a.status.value,
        ]

    _ALLOC_HEADERS = ["ID", "Food", "Qty", "Donor", "Charity", "km", "Score", "Pick up by", "Status"]

    # ---- actions --------------------------------------------------------- #
    def register_donor(self) -> None:
        name = self.p.text("Donor name")
        donor_type = self.p.choose_enum("Donor type", DonorType)
        contact = self.p.text("Contact (phone/email, optional)", required=False)
        location = self._ask_location("Location (latitude, longitude)")
        donor = self.coord.register_donor(name, donor_type, location, contact)
        self.p.say(f"Registered donor '{donor.name}' (id {donor.id}).")

    def post_food(self) -> None:
        donors = sorted(self.store.donors.values(), key=lambda d: d.name.lower())
        if not donors:
            self.p.say("  ! No donors registered yet - register a donor first (option 1).")
            return
        donor = self.p.choose("Select donor number", donors, lambda d: f"{d.name} ({_label(d.donor_type)})")
        name = self.p.text("Food description")
        category = self.p.choose_enum("Category", FoodCategory)
        quantity = self.p.ask("Quantity (portions)", lambda s: parse_int(s, 1))
        expires_at = self.p.ask(
            "Expires in (e.g. 2h, 90m, 1h30m) or at (YYYY-MM-DD HH:MM)",
            lambda s: parse_expiry(s, self.coord.clock()),
        )
        pickup = self.p.ask(
            "Pickup location 'lat, lon' (blank = donor's location)",
            lambda s: parse_location(s) if s else None,
        )
        item = self.coord.post_food(donor.id, name, category, quantity, expires_at, pickup)
        self.p.say(
            f"Posted {item.quantity} x '{item.name}' (id {item.id}), "
            f"expires in {format_timedelta(item.time_left(self.coord.clock()))}. "
            "Run matching (option 6) to assign it."
        )

    def register_charity(self) -> None:
        name = self.p.text("Charity name")
        contact = self.p.text("Contact (phone/email, optional)", required=False)
        location = self._ask_location("Location (latitude, longitude)")
        needed = self.p.ask("Portions currently needed", lambda s: parse_int(s, 0))
        categories = list(FoodCategory)
        for i, c in enumerate(categories, 1):
            self.p.say(f"  {i}. {_label(c)}")
        picked = self.p.ask(
            "Accepted categories (numbers separated by commas, blank = all)",
            lambda s: parse_index_list(s, len(categories)),
        )
        max_km = self.p.ask("Maximum pickup distance in km", parse_positive_float, default=25)
        charity = self.coord.register_charity(
            name, location, needed, [categories[i - 1] for i in picked], max_km, contact
        )
        self.p.say(f"Registered charity '{charity.name}' (id {charity.id}).")

    def view_food(self) -> None:
        items = self.coord.available_items()
        if not items:
            self.p.say("No food is currently available.")
            return
        now = self.coord.clock()
        rows = [
            [i.id, i.name, _label(i.category), f"{i.remaining}/{i.quantity}",
             self._donor_name(i.donor_id), format_timedelta(i.time_left(now)),
             i.pickup_location.describe()]
            for i in items
        ]
        self.p.say(format_table(["ID", "Food", "Category", "Left", "Donor", "Expires in", "Pickup"], rows))

    def view_charities(self) -> None:
        charities = sorted(self.store.charities.values(), key=lambda c: c.name.lower())
        if not charities:
            self.p.say("No charities registered.")
            return
        rows = [
            [c.id, c.name, c.needed,
             ", ".join(sorted(_label(x) for x in c.accepted_categories)) or "All",
             f"{c.max_distance_km:g}", c.location.describe()]
            for c in charities
        ]
        self.p.say(format_table(["ID", "Name", "Needs", "Accepts", "Max km", "Location"], rows))

    def run_matching(self) -> None:
        if not self.store.items or not self.store.charities:
            self.p.say("  ! Need at least one food item and one charity to run matching.")
            return
        result = self.coord.run_matching()
        if result.allocations:
            self.p.say(
                f"Created {len(result.allocations)} allocation(s) covering "
                f"{result.total_portions} portion(s):"
            )
            self.p.say(format_table(self._ALLOC_HEADERS, [self._allocation_row(a) for a in result.allocations]))
        else:
            self.p.say("No new matches could be made.")
        if result.unmatched:
            self.p.say("Unmatched leftovers (no suitable charity in range / with need):")
            for item_id, left in result.unmatched.items():
                self.p.say(f"  - {self.store.get_item(item_id).name}: {left} portion(s)")

    def view_log(self) -> None:
        allocations = sorted(self.store.allocations.values(), key=lambda a: (a.created_at, a.id))
        if not allocations:
            self.p.say("The distribution log is empty.")
            return
        self.p.say(format_table(self._ALLOC_HEADERS, [self._allocation_row(a) for a in allocations]))
        stats = self.coord.stats()
        self.p.say(
            f"\nTotals: {stats['portions_posted']} posted, {stats['portions_allocated']} allocated, "
            f"{stats['portions_delivered']} delivered."
        )

    def update_allocation(self) -> None:
        scheduled = self.coord.scheduled_allocations()
        if not scheduled:
            self.p.say("There are no scheduled allocations.")
            return
        alloc = self.p.choose(
            "Select allocation number",
            scheduled,
            lambda a: " | ".join(str(x) for x in self._allocation_row(a)[:5]),
        )
        action = self.p.choose("Action", ["Mark completed", "Cancel"], str)
        if action == "Mark completed":
            self.coord.complete_allocation(alloc.id)
            self.p.say("Allocation marked as completed.")
        else:
            self.coord.cancel_allocation(alloc.id)
            self.p.say("Allocation cancelled; portions returned to the pool.")

    def update_need(self) -> None:
        charities = sorted(self.store.charities.values(), key=lambda c: c.name.lower())
        if not charities:
            self.p.say("No charities registered.")
            return
        charity: Charity = self.p.choose("Select charity number", charities, lambda c: f"{c.name} (needs {c.needed})")
        needed = self.p.ask("New number of portions needed", lambda s: parse_int(s, 0))
        self.coord.update_charity_need(charity.id, needed)
        self.p.say(f"Updated '{charity.name}': needs {needed} portion(s).")

    def load_demo(self) -> None:
        load_demo_data(self.coord)
        self.p.say("Demo data loaded (3 donors, 4 charities, 4 food items). Try option 6!")


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #
def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="foodshare", description="Smart Food Waste & Donation Coordinator"
    )
    parser.add_argument(
        "--data", default=DEFAULT_DATA_FILE,
        help=f"path to the JSON data file (default: {DEFAULT_DATA_FILE})",
    )
    args = parser.parse_args(argv)
    try:
        store = DataStore.load(args.data)
    except StorageError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    return App(Coordinator(store)).run()


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
