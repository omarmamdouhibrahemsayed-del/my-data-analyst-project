"""Application service layer: business rules on top of the data store."""

from __future__ import annotations

from datetime import datetime
from typing import Callable, Dict, Iterable, List, Optional

from .errors import ValidationError
from .matching import MatchConfig, MatchResult, match
from .models import (
    Allocation,
    AllocationStatus,
    Charity,
    Donor,
    DonorType,
    FoodCategory,
    FoodItem,
    ItemStatus,
    Location,
    utcnow,
)
from .storage import DataStore


class Coordinator:
    """Facade used by the CLI (and any future GUI/API) to drive the system.

    Every mutating operation persists the store automatically.
    """

    def __init__(
        self,
        store: DataStore,
        config: Optional[MatchConfig] = None,
        clock: Callable[[], datetime] = utcnow,
    ) -> None:
        self.store = store
        self.config = config or MatchConfig()
        self.clock = clock

    # ---- registration ---------------------------------------------------- #
    def register_donor(
        self, name: str, donor_type: DonorType, location: Location, contact: str = ""
    ) -> Donor:
        donor = self.store.add_donor(Donor(name, donor_type, location, contact))
        self.store.save()
        return donor

    def register_charity(
        self,
        name: str,
        location: Location,
        needed: int,
        accepted_categories: Iterable[FoodCategory] = (),
        max_distance_km: float = 25.0,
        contact: str = "",
    ) -> Charity:
        charity = self.store.add_charity(
            Charity(
                name=name,
                location=location,
                needed=needed,
                accepted_categories=frozenset(accepted_categories),
                max_distance_km=max_distance_km,
                contact=contact,
            )
        )
        self.store.save()
        return charity

    def update_charity_need(self, charity_id: str, needed: int) -> Charity:
        charity = self.store.get_charity(charity_id)
        if isinstance(needed, bool) or not isinstance(needed, int) or needed < 0:
            raise ValidationError("Portions needed must be a non-negative whole number.")
        charity.needed = needed
        self.store.save()
        return charity

    # ---- food posting ---------------------------------------------------- #
    def post_food(
        self,
        donor_id: str,
        name: str,
        category: FoodCategory,
        quantity: int,
        expires_at: datetime,
        pickup_location: Optional[Location] = None,
    ) -> FoodItem:
        donor = self.store.get_donor(donor_id)
        now = self.clock()
        item = FoodItem(
            donor_id=donor.id,
            name=name,
            category=category,
            quantity=quantity,
            expires_at=expires_at,
            pickup_location=pickup_location or donor.location,
            posted_at=now,
        )
        if item.is_expired(now):
            raise ValidationError("Expiration time must be in the future.")
        self.store.add_item(item)
        self.store.save()
        return item

    def expire_items(self) -> int:
        """Refresh item statuses; returns how many items just became expired."""
        now = self.clock()
        count = 0
        for item in self.store.items.values():
            before = item.status
            item.refresh_status(now)
            if before is not ItemStatus.EXPIRED and item.status is ItemStatus.EXPIRED:
                count += 1
        return count

    def available_items(self) -> List[FoodItem]:
        """Items that can still be matched, soonest-expiring first."""
        self.expire_items()
        return sorted(
            (i for i in self.store.items.values() if i.status is ItemStatus.AVAILABLE),
            key=lambda i: (i.expires_at, i.id),
        )

    # ---- matching & allocation lifecycle --------------------------------- #
    def run_matching(self) -> MatchResult:
        """Run the matcher on current data and persist the new allocations."""
        now = self.clock()
        self.expire_items()
        result = match(
            self.store.items.values(), self.store.charities.values(), now, self.config
        )
        for alloc in result.allocations:
            item = self.store.get_item(alloc.item_id)
            charity = self.store.get_charity(alloc.charity_id)
            item.reserve(alloc.quantity)
            charity.needed -= alloc.quantity
            item.refresh_status(now)
            self.store.add_allocation(alloc)
        self.store.save()
        return result

    def scheduled_allocations(self) -> List[Allocation]:
        return sorted(
            (a for a in self.store.allocations.values()
             if a.status is AllocationStatus.SCHEDULED),
            key=lambda a: (a.pickup_by, a.id),
        )

    def complete_allocation(self, allocation_id: str) -> Allocation:
        alloc = self.store.get_allocation(allocation_id)
        self._require_scheduled(alloc)
        alloc.status = AllocationStatus.COMPLETED
        self.store.save()
        return alloc

    def cancel_allocation(self, allocation_id: str) -> Allocation:
        """Cancel a scheduled allocation and return its portions to the pool."""
        alloc = self.store.get_allocation(allocation_id)
        self._require_scheduled(alloc)
        item = self.store.get_item(alloc.item_id)
        charity = self.store.get_charity(alloc.charity_id)
        item.release(alloc.quantity)
        charity.needed += alloc.quantity
        item.refresh_status(self.clock())
        alloc.status = AllocationStatus.CANCELLED
        self.store.save()
        return alloc

    @staticmethod
    def _require_scheduled(alloc: Allocation) -> None:
        if alloc.status is not AllocationStatus.SCHEDULED:
            raise ValidationError(
                f"Allocation {alloc.id} is already {alloc.status.value}."
            )

    # ---- reporting ------------------------------------------------------- #
    def stats(self) -> Dict[str, int]:
        allocs = self.store.allocations.values()
        return {
            "donors": len(self.store.donors),
            "charities": len(self.store.charities),
            "items": len(self.store.items),
            "portions_posted": sum(i.quantity for i in self.store.items.values()),
            "portions_allocated": sum(
                a.quantity for a in allocs if a.status is not AllocationStatus.CANCELLED
            ),
            "portions_delivered": sum(
                a.quantity for a in allocs if a.status is AllocationStatus.COMPLETED
            ),
        }
