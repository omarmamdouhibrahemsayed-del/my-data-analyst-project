"""Exception hierarchy used across the application."""

from __future__ import annotations


class FoodShareError(Exception):
    """Base class for all expected, user-facing application errors."""


class ValidationError(FoodShareError, ValueError):
    """Raised when supplied data is invalid (bad input, bad state change)."""


class NotFoundError(FoodShareError):
    """Raised when a referenced donor, charity, item or allocation is unknown."""


class StorageError(FoodShareError):
    """Raised when the data file cannot be read, parsed or written."""
