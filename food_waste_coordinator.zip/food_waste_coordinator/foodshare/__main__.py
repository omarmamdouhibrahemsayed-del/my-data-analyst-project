"""Allow ``python -m foodshare``."""

import sys

from .cli import main

sys.exit(main())
