"""Small geographic helpers (no third-party dependencies)."""

from __future__ import annotations

import math

from .models import Location

EARTH_RADIUS_KM = 6371.0088


def haversine_km(a: Location, b: Location) -> float:
    """Great-circle distance between two locations in kilometres."""
    lat1, lon1 = math.radians(a.lat), math.radians(a.lon)
    lat2, lon2 = math.radians(b.lat), math.radians(b.lon)
    d_lat, d_lon = lat2 - lat1, lon2 - lon1
    h = math.sin(d_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(d_lon / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(min(1.0, math.sqrt(h)))


def estimate_travel_minutes(distance_km: float, avg_speed_kmph: float) -> float:
    """Rough travel time in minutes at a constant average speed."""
    if avg_speed_kmph <= 0:
        raise ValueError("avg_speed_kmph must be positive")
    return distance_km / avg_speed_kmph * 60.0
