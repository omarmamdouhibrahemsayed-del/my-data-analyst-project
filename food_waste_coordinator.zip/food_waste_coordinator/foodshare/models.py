"""Domain models: locations, donors, food items, charities and allocations.

All models validate their data on construction and can be converted to and
from plain dictionaries (``to_dict`` / ``from_dict``) for JSON persistence.
"""

from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, FrozenSet, Optional, Type, TypeVar

from .errors import ValidationError

E = TypeVar("E", bound=Enum)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def utcnow() -> datetime:
    """Current time as a timezone-aware UTC datetime."""
    return datetime.now(timezone.utc)


def to_utc(dt: datetime) -> datetime:
    """Normalise a datetime to UTC. Naive datetimes are treated as local time."""
    return dt.astimezone(timezone.utc)


def parse_iso(value: str) -> datetime:
    """Parse an ISO-8601 string into an aware UTC datetime."""
    try:
        return to_utc(datetime.fromisoformat(value))
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"Invalid date/time: {value!r}") from exc


def new_id(prefix: str) -> str:
    """Generate a short unique identifier such as ``D-1a2b3c4d``."""
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def _coerce_enum(enum_cls: Type[E], value: Any, field_name: str) -> E:
    if isinstance(value, enum_cls):
        return value
    if isinstance(value, str):
        key = value.strip().lower()
        for member in enum_cls:
            if key in (str(member.value).lower(), member.name.lower()):
                return member
    allowed = ", ".join(str(m.value) for m in enum_cls)
    raise ValidationError(f"Invalid {field_name}: {value!r}. Expected one of: {allowed}")


def _require_int(value: Any, name: str, minimum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValidationError(f"{name} must be a whole number.")
    if value < minimum:
        raise ValidationError(f"{name} must be at least {minimum}.")
    return value


def _require_name(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValidationError(f"{name} must not be empty.")
    return value.strip()


# --------------------------------------------------------------------------- #
# Enums
# --------------------------------------------------------------------------- #
class DonorType(str, Enum):
    RESTAURANT = "restaurant"
    EVENT = "event"
    INDIVIDUAL = "individual"
    GROCERY = "grocery"
    OTHER = "other"


class FoodCategory(str, Enum):
    PREPARED = "prepared"
    PRODUCE = "produce"
    BAKERY = "bakery"
    DAIRY = "dairy"
    PACKAGED = "packaged"
    BEVERAGE = "beverage"
    OTHER = "other"


class ItemStatus(str, Enum):
    AVAILABLE = "available"
    ALLOCATED = "allocated"
    EXPIRED = "expired"


class AllocationStatus(str, Enum):
    SCHEDULED = "scheduled"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


# --------------------------------------------------------------------------- #
# Location
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Location:
    """A point on Earth with an optional human-readable label."""

    lat: float
    lon: float
    label: str = ""

    def __post_init__(self) -> None:
        for name, value, limit in (("Latitude", self.lat, 90), ("Longitude", self.lon, 180)):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValidationError(f"{name} must be a number.")
            if not math.isfinite(value) or abs(value) > limit:
                raise ValidationError(f"{name} must be between -{limit} and {limit}.")

    def describe(self) -> str:
        coords = f"{self.lat:.4f}, {self.lon:.4f}"
        return f"{self.label} ({coords})" if self.label else coords

    def to_dict(self) -> Dict[str, Any]:
        return {"lat": self.lat, "lon": self.lon, "label": self.label}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Location":
        return cls(lat=data["lat"], lon=data["lon"], label=data.get("label", ""))


# --------------------------------------------------------------------------- #
# Donor
# --------------------------------------------------------------------------- #
@dataclass
class Donor:
    """A restaurant, event organiser, grocery or individual with surplus food."""

    name: str
    donor_type: DonorType
    location: Location
    contact: str = ""
    id: str = field(default_factory=lambda: new_id("D"))

    def __post_init__(self) -> None:
        self.name = _require_name(self.name, "Donor name")
        self.donor_type = _coerce_enum(DonorType, self.donor_type, "donor type")
        self.contact = (self.contact or "").strip()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "donor_type": self.donor_type.value,
            "location": self.location.to_dict(),
            "contact": self.contact,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Donor":
        return cls(
            id=data["id"],
            name=data["name"],
            donor_type=data["donor_type"],
            location=Location.from_dict(data["location"]),
            contact=data.get("contact", ""),
        )


# --------------------------------------------------------------------------- #
# Food item
# --------------------------------------------------------------------------- #
@dataclass
class FoodItem:
    """A batch of surplus food posted by a donor.

    ``quantity`` is the originally posted amount (in portions); ``remaining``
    is what has not yet been allocated to a charity.
    """

    donor_id: str
    name: str
    category: FoodCategory
    quantity: int
    expires_at: datetime
    pickup_location: Location
    posted_at: datetime = field(default_factory=utcnow)
    remaining: Optional[int] = None
    status: ItemStatus = ItemStatus.AVAILABLE
    id: str = field(default_factory=lambda: new_id("F"))

    def __post_init__(self) -> None:
        self.name = _require_name(self.name, "Food name")
        self.category = _coerce_enum(FoodCategory, self.category, "category")
        self.status = _coerce_enum(ItemStatus, self.status, "status")
        self.quantity = _require_int(self.quantity, "Quantity", 1)
        self.expires_at = to_utc(self.expires_at)
        self.posted_at = to_utc(self.posted_at)
        if self.remaining is None:
            self.remaining = self.quantity
        self.remaining = _require_int(self.remaining, "Remaining quantity", 0)
        if self.remaining > self.quantity:
            raise ValidationError("Remaining quantity cannot exceed the posted quantity.")

    def time_left(self, now: datetime) -> timedelta:
        return self.expires_at - to_utc(now)

    def is_expired(self, now: datetime) -> bool:
        return to_utc(now) >= self.expires_at

    def refresh_status(self, now: datetime) -> None:
        """Recompute ``status`` from remaining quantity and the clock."""
        if self.remaining == 0:
            self.status = ItemStatus.ALLOCATED
        elif self.is_expired(now):
            self.status = ItemStatus.EXPIRED
        else:
            self.status = ItemStatus.AVAILABLE

    def reserve(self, quantity: int) -> None:
        """Take ``quantity`` portions out of the unallocated pool."""
        if quantity <= 0 or quantity > (self.remaining or 0):
            raise ValidationError(
                f"Cannot reserve {quantity} portions; only {self.remaining} remaining."
            )
        self.remaining = (self.remaining or 0) - quantity

    def release(self, quantity: int) -> None:
        """Return ``quantity`` portions to the unallocated pool."""
        if quantity <= 0 or (self.remaining or 0) + quantity > self.quantity:
            raise ValidationError("Invalid quantity to release.")
        self.remaining = (self.remaining or 0) + quantity

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "donor_id": self.donor_id,
            "name": self.name,
            "category": self.category.value,
            "quantity": self.quantity,
            "remaining": self.remaining,
            "expires_at": self.expires_at.isoformat(),
            "pickup_location": self.pickup_location.to_dict(),
            "posted_at": self.posted_at.isoformat(),
            "status": self.status.value,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FoodItem":
        return cls(
            id=data["id"],
            donor_id=data["donor_id"],
            name=data["name"],
            category=data["category"],
            quantity=data["quantity"],
            remaining=data["remaining"],
            expires_at=parse_iso(data["expires_at"]),
            pickup_location=Location.from_dict(data["pickup_location"]),
            posted_at=parse_iso(data["posted_at"]),
            status=data["status"],
        )


# --------------------------------------------------------------------------- #
# Charity / recipient
# --------------------------------------------------------------------------- #
@dataclass
class Charity:
    """A charity or volunteer group that can collect and distribute food.

    ``needed`` is the number of portions the charity can currently absorb.
    An empty ``accepted_categories`` set means every category is accepted.
    """

    name: str
    location: Location
    needed: int = 0
    accepted_categories: FrozenSet[FoodCategory] = field(default_factory=frozenset)
    max_distance_km: float = 25.0
    contact: str = ""
    id: str = field(default_factory=lambda: new_id("C"))

    def __post_init__(self) -> None:
        self.name = _require_name(self.name, "Charity name")
        self.needed = _require_int(self.needed, "Portions needed", 0)
        self.accepted_categories = frozenset(
            _coerce_enum(FoodCategory, c, "category") for c in self.accepted_categories
        )
        if (
            isinstance(self.max_distance_km, bool)
            or not isinstance(self.max_distance_km, (int, float))
            or not math.isfinite(self.max_distance_km)
            or self.max_distance_km <= 0
        ):
            raise ValidationError("Maximum distance must be a positive number.")
        self.max_distance_km = float(self.max_distance_km)
        self.contact = (self.contact or "").strip()

    def accepts(self, category: FoodCategory) -> bool:
        return not self.accepted_categories or category in self.accepted_categories

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "location": self.location.to_dict(),
            "needed": self.needed,
            "accepted_categories": sorted(c.value for c in self.accepted_categories),
            "max_distance_km": self.max_distance_km,
            "contact": self.contact,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Charity":
        return cls(
            id=data["id"],
            name=data["name"],
            location=Location.from_dict(data["location"]),
            needed=data["needed"],
            accepted_categories=frozenset(data.get("accepted_categories", [])),
            max_distance_km=data.get("max_distance_km", 25.0),
            contact=data.get("contact", ""),
        )


# --------------------------------------------------------------------------- #
# Allocation (a match between an item and a charity)
# --------------------------------------------------------------------------- #
@dataclass
class Allocation:
    """A scheduled hand-over of ``quantity`` portions of an item to a charity."""

    item_id: str
    charity_id: str
    quantity: int
    distance_km: float
    score: float
    pickup_by: datetime
    created_at: datetime = field(default_factory=utcnow)
    status: AllocationStatus = AllocationStatus.SCHEDULED
    id: str = field(default_factory=lambda: new_id("A"))

    def __post_init__(self) -> None:
        self.quantity = _require_int(self.quantity, "Allocation quantity", 1)
        self.status = _coerce_enum(AllocationStatus, self.status, "allocation status")
        self.pickup_by = to_utc(self.pickup_by)
        self.created_at = to_utc(self.created_at)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "item_id": self.item_id,
            "charity_id": self.charity_id,
            "quantity": self.quantity,
            "distance_km": self.distance_km,
            "score": self.score,
            "pickup_by": self.pickup_by.isoformat(),
            "created_at": self.created_at.isoformat(),
            "status": self.status.value,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Allocation":
        return cls(
            id=data["id"],
            item_id=data["item_id"],
            charity_id=data["charity_id"],
            quantity=data["quantity"],
            distance_km=data["distance_km"],
            score=data["score"],
            pickup_by=parse_iso(data["pickup_by"]),
            created_at=parse_iso(data["created_at"]),
            status=data["status"],
        )
