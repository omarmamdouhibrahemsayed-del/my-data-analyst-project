"""JSON-file persistence for the application state."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, TypeVar, Union

from .errors import NotFoundError, StorageError, ValidationError
from .models import Allocation, Charity, Donor, FoodItem

SCHEMA_VERSION = 1
T = TypeVar("T")


class DataStore:
    """In-memory collections with optional atomic JSON persistence.

    If ``path`` is ``None`` the store lives purely in memory (handy for tests).
    """

    def __init__(self, path: Optional[Union[str, Path]] = None) -> None:
        self.path: Optional[Path] = Path(path) if path else None
        self.donors: Dict[str, Donor] = {}
        self.charities: Dict[str, Charity] = {}
        self.items: Dict[str, FoodItem] = {}
        self.allocations: Dict[str, Allocation] = {}

    # ---- lookups --------------------------------------------------------- #
    @staticmethod
    def _get(mapping: Dict[str, T], key: str, kind: str) -> T:
        try:
            return mapping[key]
        except KeyError:
            raise NotFoundError(f"Unknown {kind}: {key!r}") from None

    def get_donor(self, donor_id: str) -> Donor:
        return self._get(self.donors, donor_id, "donor")

    def get_charity(self, charity_id: str) -> Charity:
        return self._get(self.charities, charity_id, "charity")

    def get_item(self, item_id: str) -> FoodItem:
        return self._get(self.items, item_id, "food item")

    def get_allocation(self, allocation_id: str) -> Allocation:
        return self._get(self.allocations, allocation_id, "allocation")

    # ---- inserts --------------------------------------------------------- #
    @staticmethod
    def _insert(mapping: Dict[str, T], obj: Any, kind: str) -> None:
        if obj.id in mapping:
            raise ValidationError(f"Duplicate {kind} id: {obj.id}")
        mapping[obj.id] = obj

    def add_donor(self, donor: Donor) -> Donor:
        self._insert(self.donors, donor, "donor")
        return donor

    def add_charity(self, charity: Charity) -> Charity:
        self._insert(self.charities, charity, "charity")
        return charity

    def add_item(self, item: FoodItem) -> FoodItem:
        self.get_donor(item.donor_id)  # referential integrity
        self._insert(self.items, item, "food item")
        return item

    def add_allocation(self, allocation: Allocation) -> Allocation:
        self.get_item(allocation.item_id)
        self.get_charity(allocation.charity_id)
        self._insert(self.allocations, allocation, "allocation")
        return allocation

    # ---- serialisation --------------------------------------------------- #
    def to_dict(self) -> Dict[str, Any]:
        allocations: List[Allocation] = sorted(
            self.allocations.values(), key=lambda a: (a.created_at, a.id)
        )
        return {
            "schema_version": SCHEMA_VERSION,
            "donors": [d.to_dict() for d in self.donors.values()],
            "charities": [c.to_dict() for c in self.charities.values()],
            "items": [i.to_dict() for i in self.items.values()],
            "allocations": [a.to_dict() for a in allocations],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], path: Optional[Union[str, Path]] = None) -> "DataStore":
        if not isinstance(data, dict):
            raise StorageError("Data file must contain a JSON object.")
        if data.get("schema_version") != SCHEMA_VERSION:
            raise StorageError(
                f"Unsupported schema version: {data.get('schema_version')!r} "
                f"(expected {SCHEMA_VERSION})."
            )
        store = cls(path)
        try:
            for d in data["donors"]:
                store.add_donor(Donor.from_dict(d))
            for c in data["charities"]:
                store.add_charity(Charity.from_dict(c))
            for i in data["items"]:
                store.add_item(FoodItem.from_dict(i))
            for a in data["allocations"]:
                store.add_allocation(Allocation.from_dict(a))
        except (KeyError, TypeError, ValueError, AttributeError) as exc:
            raise StorageError(f"Data file is malformed: {exc!r}") from exc
        except (NotFoundError,) as exc:
            raise StorageError(f"Data file has broken references: {exc}") from exc
        return store

    # ---- file I/O -------------------------------------------------------- #
    @classmethod
    def load(cls, path: Union[str, Path]) -> "DataStore":
        """Load a store from ``path``; a missing file yields an empty store."""
        p = Path(path)
        if not p.exists():
            return cls(p)
        try:
            raw = p.read_text(encoding="utf-8")
        except OSError as exc:
            raise StorageError(f"Cannot read {p}: {exc}") from exc
        if not raw.strip():
            return cls(p)
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise StorageError(f"{p} is not valid JSON: {exc}") from exc
        return cls.from_dict(data, p)

    def save(self) -> None:
        """Atomically write the store to disk (no-op for in-memory stores)."""
        if self.path is None:
            return
        tmp = self.path.with_name(self.path.name + ".tmp")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError as exc:
            raise StorageError(f"Cannot write {self.path}: {exc}") from exc
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass
