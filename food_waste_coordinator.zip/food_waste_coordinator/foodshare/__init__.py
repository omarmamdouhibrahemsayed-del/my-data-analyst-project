"""Smart Food Waste & Donation Coordinator."""

__version__ = "1.0.0"
