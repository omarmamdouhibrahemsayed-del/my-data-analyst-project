"""Pure input-parsing helpers used by the CLI (easy to unit test)."""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import List, Optional

from .errors import ValidationError
from .models import Location, to_utc

_DURATION_RE = re.compile(
    r"^\s*(?:(\d+(?:\.\d+)?)\s*h(?:ours?|rs?)?)?\s*(?:(\d+)\s*m(?:in(?:ute)?s?)?)?\s*$",
    re.IGNORECASE,
)
_DATETIME_FORMATS = ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d")


def parse_int(text: str, minimum: Optional[int] = None, maximum: Optional[int] = None) -> int:
    """Parse a whole number within optional bounds."""
    try:
        value = int(text.strip())
    except (ValueError, AttributeError):
        raise ValidationError(f"{text!r} is not a whole number.") from None
    if minimum is not None and value < minimum:
        raise ValidationError(f"Value must be at least {minimum}.")
    if maximum is not None and value > maximum:
        raise ValidationError(f"Value must be at most {maximum}.")
    return value


def parse_positive_float(text: str) -> float:
    """Parse a float strictly greater than zero."""
    try:
        value = float(text.strip())
    except (ValueError, AttributeError):
        raise ValidationError(f"{text!r} is not a number.") from None
    if not value > 0 or value == float("inf"):
        raise ValidationError("Value must be a positive number.")
    return value


def parse_location(text: str) -> Location:
    """Parse ``"lat, lon"`` (comma or whitespace separated)."""
    parts = [p for p in re.split(r"[,\s]+", text.strip()) if p]
    if len(parts) != 2:
        raise ValidationError("Enter coordinates as 'latitude, longitude' (e.g. 40.7128, -74.0060).")
    try:
        lat, lon = float(parts[0]), float(parts[1])
    except ValueError:
        raise ValidationError("Latitude and longitude must be numbers.") from None
    return Location(lat, lon)  # range-validated by Location


def parse_expiry(text: str, now: datetime) -> datetime:
    """Parse an expiry given as a duration ('2h', '90m', '1h30m') or a date.

    Dates use ``YYYY-MM-DD HH:MM`` (or ``YYYY-MM-DD``) in local time.
    Returns an aware UTC datetime.
    """
    match = _DURATION_RE.match(text)
    if match and (match.group(1) or match.group(2)):
        hours = float(match.group(1) or 0)
        minutes = int(match.group(2) or 0)
        delta = timedelta(hours=hours, minutes=minutes)
        if delta <= timedelta(0):
            raise ValidationError("Duration must be greater than zero.")
        return to_utc(now) + delta
    for fmt in _DATETIME_FORMATS:
        try:
            return to_utc(datetime.strptime(text.strip(), fmt))
        except ValueError:
            continue
    raise ValidationError(
        "Could not understand that time. Use e.g. '2h', '90m', '1h30m' or '2026-03-01 18:30'."
    )


def parse_index_list(text: str, maximum: int) -> List[int]:
    """Parse ``"1, 3"`` into sorted unique 1-based indexes. Blank gives ``[]``."""
    if not text.strip():
        return []
    values = {parse_int(p, 1, maximum) for p in re.split(r"[,\s]+", text.strip()) if p}
    return sorted(values)
