"""Sample data so the system can be explored immediately."""

from __future__ import annotations

from datetime import timedelta

from .models import DonorType, FoodCategory, Location
from .service import Coordinator


def load_demo_data(coord: Coordinator) -> None:
    """Populate ``coord`` with a few donors, charities and surplus items."""
    now = coord.clock()
    bistro = coord.register_donor(
        "Green Bistro", DonorType.RESTAURANT, Location(40.7128, -74.0060, "Downtown"), "555-0101"
    )
    bakery = coord.register_donor(
        "Daily Bread Bakery", DonorType.GROCERY, Location(40.7306, -73.9866, "East Side"), "555-0102"
    )
    gala = coord.register_donor(
        "City Gala Event", DonorType.EVENT, Location(40.7580, -73.9855, "Midtown"), "555-0103"
    )

    coord.register_charity(
        "Hope Kitchen", Location(40.7200, -74.0000, "Hope St"), 60, [], 20.0, "555-0201"
    )
    coord.register_charity(
        "Shelter Network", Location(40.7420, -73.9900, "Shelter Ave"), 40,
        [FoodCategory.PREPARED, FoodCategory.PACKAGED], 15.0, "555-0202",
    )
    coord.register_charity(
        "Community Pantry", Location(40.6782, -73.9442, "Pantry Rd"), 80,
        [FoodCategory.PRODUCE, FoodCategory.BAKERY, FoodCategory.DAIRY], 30.0, "555-0203",
    )
    coord.register_charity(
        "Youth Centre Meals", Location(40.7650, -73.9800, "Youth Way"), 25, [], 10.0, "555-0204"
    )

    coord.post_food(bistro.id, "Vegetable lasagna", FoodCategory.PREPARED, 45, now + timedelta(hours=3))
    coord.post_food(bakery.id, "Assorted bread", FoodCategory.BAKERY, 70, now + timedelta(hours=10))
    coord.post_food(gala.id, "Buffet leftovers", FoodCategory.PREPARED, 90, now + timedelta(hours=2))
    coord.post_food(bistro.id, "Fresh salad boxes", FoodCategory.PRODUCE, 30, now + timedelta(hours=6))
