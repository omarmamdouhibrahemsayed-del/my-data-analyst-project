"""Shared fixtures and factories for the test-suite."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Callable, Iterable

import pytest

from foodshare.models import Charity, FoodCategory, FoodItem, Location
from foodshare.service import Coordinator
from foodshare.storage import DataStore

NOW = datetime(2026, 1, 1, 12, 0, tzinfo=timezone.utc)

# 0.01 degrees of latitude is roughly 1.11 km.
ORIGIN = (40.0, -74.0)
NEAR = (40.01, -74.0)   # ~1.1 km from ORIGIN
MID = (40.02, -74.0)    # ~2.2 km
FAR = (40.1, -74.0)     # ~11.1 km


@pytest.fixture
def now() -> datetime:
    return NOW


@pytest.fixture
def make_item() -> Callable[..., FoodItem]:
    def _make(
        name: str = "Pasta",
        quantity: int = 20,
        hours: float = 4,
        category: FoodCategory = FoodCategory.PREPARED,
        loc: tuple = ORIGIN,
        **kwargs,
    ) -> FoodItem:
        return FoodItem(
            donor_id="D-1",
            name=name,
            category=category,
            quantity=quantity,
            expires_at=NOW + timedelta(hours=hours),
            pickup_location=Location(*loc),
            posted_at=NOW,
            **kwargs,
        )

    return _make


@pytest.fixture
def make_charity() -> Callable[..., Charity]:
    def _make(
        name: str = "Charity",
        loc: tuple = NEAR,
        needed: int = 20,
        categories: Iterable[FoodCategory] = (),
        max_km: float = 25.0,
    ) -> Charity:
        return Charity(
            name=name,
            location=Location(*loc),
            needed=needed,
            accepted_categories=frozenset(categories),
            max_distance_km=max_km,
        )

    return _make


@pytest.fixture
def coordinator() -> Coordinator:
    """In-memory coordinator with a frozen clock."""
    return Coordinator(DataStore(), clock=lambda: NOW)
