import random
from datetime import timedelta

import pytest

from foodshare.errors import ValidationError
from foodshare.matching import MatchConfig, match, urgency_factor
from foodshare.models import FoodCategory, ItemStatus
from conftest import FAR, MID, NEAR


def test_prefers_nearest_charity(make_item, make_charity, now):
    item = make_item(quantity=20)
    near = make_charity("Near", NEAR)
    far = make_charity("Far", FAR)
    result = match([item], [far, near], now)
    assert len(result.allocations) == 1
    assert result.allocations[0].charity_id == near.id
    assert result.allocations[0].quantity == 20
    assert 0 < result.allocations[0].score <= 1
    assert not result.unmatched


def test_respects_category_preferences(make_item, make_charity, now):
    item = make_item(category=FoodCategory.PREPARED)
    near_wrong = make_charity("Bakery only", NEAR, categories=[FoodCategory.BAKERY])
    far_ok = make_charity("Any", FAR)
    result = match([item], [near_wrong, far_ok], now)
    assert [a.charity_id for a in result.allocations] == [far_ok.id]


def test_respects_max_distance(make_item, make_charity, now):
    item = make_item()
    charity = make_charity(loc=FAR, max_km=5)
    result = match([item], [charity], now)
    assert result.allocations == [] and result.unmatched == {item.id: 20}


def test_infeasible_if_cannot_arrive_before_expiry(make_item, make_charity, now):
    # 30 minutes left; ~11 km at 30 km/h (22 min) + 15 min buffer = too late.
    item = make_item(hours=0.5)
    far = make_charity("Far", FAR)
    assert match([item], [far], now).allocations == []
    near = make_charity("Near", NEAR)  # ~2 min + 15 min buffer: fine
    assert match([item], [far, near], now).allocations[0].charity_id == near.id


def test_large_donation_is_split_across_charities(make_item, make_charity, now):
    item = make_item(quantity=30)
    near = make_charity("Near", NEAR, needed=20)
    far = make_charity("Far", FAR, needed=20)
    result = match([item], [near, far], now)
    got = {a.charity_id: a.quantity for a in result.allocations}
    assert got == {near.id: 20, far.id: 10}


def test_leftover_reported_when_need_is_insufficient(make_item, make_charity, now):
    item = make_item(quantity=50)
    result = match([item], [make_charity(needed=15)], now)
    assert result.total_portions == 15
    assert result.unmatched == {item.id: 35}


def test_quantity_fit_can_outweigh_slight_distance(make_item, make_charity, now):
    item = make_item(quantity=30)
    tiny_need_near = make_charity("Tiny", NEAR, needed=3)
    exact_need_mid = make_charity("Exact", MID, needed=30)
    result = match([item], [tiny_need_near, exact_need_mid], now)
    assert result.allocations[0].charity_id == exact_need_mid.id
    assert result.allocations[0].quantity == 30


def test_most_urgent_item_gets_scarce_demand_first(make_item, make_charity, now):
    urgent = make_item("Urgent", quantity=10, hours=2)
    relaxed = make_item("Relaxed", quantity=10, hours=6)
    charity = make_charity(needed=10)
    result = match([relaxed, urgent], [charity], now)
    assert [a.item_id for a in result.allocations] == [urgent.id]
    assert result.unmatched == {relaxed.id: 10}


def test_urgency_factor_bounds():
    assert urgency_factor(0, 24) == 1.0
    assert urgency_factor(12, 24) == pytest.approx(0.5)
    assert urgency_factor(100, 24) == 0.0


def test_expired_and_non_available_items_are_ignored(make_item, make_charity, now):
    expired = make_item("Old", hours=-1)
    allocated = make_item("Done", status=ItemStatus.ALLOCATED)
    assert match([expired, allocated], [make_charity()], now).allocations == []


def test_inputs_are_not_mutated(make_item, make_charity, now):
    item, charity = make_item(quantity=20), make_charity(needed=20)
    match([item], [charity], now)
    assert item.remaining == 20 and charity.needed == 20


def test_zero_need_charity_is_skipped(make_item, make_charity, now):
    assert match([make_item()], [make_charity(needed=0)], now).allocations == []


def test_never_over_allocates_randomised(make_item, make_charity, now):
    rng = random.Random(42)
    cats = list(FoodCategory)
    items = [
        make_item(f"I{n}", quantity=rng.randint(1, 60), hours=rng.uniform(0.5, 12),
                  category=rng.choice(cats), loc=(40 + rng.uniform(0, 0.1), -74 + rng.uniform(0, 0.1)))
        for n in range(15)
    ]
    charities = [
        make_charity(f"C{n}", (40 + rng.uniform(0, 0.1), -74 + rng.uniform(0, 0.1)),
                     needed=rng.randint(0, 50), categories=rng.sample(cats, rng.randint(0, 3)))
        for n in range(6)
    ]
    result = match(items, charities, now)
    by_item, by_charity = {}, {}
    for a in result.allocations:
        by_item[a.item_id] = by_item.get(a.item_id, 0) + a.quantity
        by_charity[a.charity_id] = by_charity.get(a.charity_id, 0) + a.quantity
    for i in items:
        assert by_item.get(i.id, 0) + result.unmatched.get(i.id, 0) <= i.remaining
    for c in charities:
        assert by_charity.get(c.id, 0) <= c.needed


def test_deterministic(make_item, make_charity, now):
    items = [make_item(f"I{n}", quantity=10 + n) for n in range(4)]
    charities = [make_charity(f"C{n}", (40.01 + n / 100, -74.0), needed=15) for n in range(4)]
    key = lambda r: [(a.item_id, a.charity_id, a.quantity) for a in r.allocations]
    assert key(match(items, charities, now)) == key(match(list(reversed(items)), charities, now))


@pytest.mark.parametrize(
    "kwargs",
    [{"w_proximity": -1}, {"w_proximity": 0, "w_fit": 0, "w_urgency": 0},
     {"avg_speed_kmph": 0}, {"urgency_horizon_hours": 0}, {"min_portions": 0}],
)
def test_invalid_config(kwargs):
    with pytest.raises(ValidationError):
        MatchConfig(**kwargs)
