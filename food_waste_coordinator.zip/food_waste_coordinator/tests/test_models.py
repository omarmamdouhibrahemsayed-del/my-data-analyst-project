import pytest

from foodshare.errors import ValidationError
from foodshare.geo import estimate_travel_minutes, haversine_km
from foodshare.models import (
    Allocation, Charity, Donor, DonorType, FoodCategory, FoodItem, ItemStatus, Location,
)


class TestLocation:
    @pytest.mark.parametrize("lat,lon", [(91, 0), (-91, 0), (0, 181), (0, -181), (float("nan"), 0)])
    def test_out_of_range_rejected(self, lat, lon):
        with pytest.raises(ValidationError):
            Location(lat, lon)

    def test_roundtrip(self):
        loc = Location(12.5, -45.25, "Somewhere")
        assert Location.from_dict(loc.to_dict()) == loc


class TestDonor:
    def test_name_is_trimmed_and_required(self):
        assert Donor("  Cafe  ", "restaurant", Location(0, 0)).name == "Cafe"
        with pytest.raises(ValidationError):
            Donor("   ", DonorType.EVENT, Location(0, 0))

    def test_invalid_type_rejected(self):
        with pytest.raises(ValidationError):
            Donor("X", "spaceship", Location(0, 0))

    def test_roundtrip(self):
        d = Donor("Cafe", DonorType.RESTAURANT, Location(1, 2), "a@b.c")
        assert Donor.from_dict(d.to_dict()) == d


class TestFoodItem:
    def test_defaults_and_validation(self, make_item):
        item = make_item(quantity=10)
        assert item.remaining == 10 and item.status is ItemStatus.AVAILABLE
        for bad in (0, -3):
            with pytest.raises(ValidationError):
                make_item(quantity=bad)
        with pytest.raises(ValidationError):
            make_item(quantity=5, remaining=6)

    def test_reserve_release_and_status(self, make_item, now):
        item = make_item(quantity=10)
        item.reserve(10)
        item.refresh_status(now)
        assert item.status is ItemStatus.ALLOCATED
        with pytest.raises(ValidationError):
            item.reserve(1)
        item.release(4)
        item.refresh_status(now)
        assert item.remaining == 4 and item.status is ItemStatus.AVAILABLE
        with pytest.raises(ValidationError):
            item.release(100)

    def test_expiry(self, make_item, now):
        item = make_item(hours=1)
        from datetime import timedelta
        assert not item.is_expired(now)
        assert item.is_expired(now + timedelta(hours=1))
        item.refresh_status(now + timedelta(hours=2))
        assert item.status is ItemStatus.EXPIRED

    def test_roundtrip(self, make_item):
        item = make_item(quantity=12, remaining=7)
        assert FoodItem.from_dict(item.to_dict()) == item


class TestCharityAndAllocation:
    def test_accepts(self, make_charity):
        assert make_charity().accepts(FoodCategory.DAIRY)  # empty set = all
        picky = make_charity(categories=[FoodCategory.BAKERY])
        assert picky.accepts(FoodCategory.BAKERY) and not picky.accepts(FoodCategory.DAIRY)

    @pytest.mark.parametrize("kwargs", [{"needed": -1}, {"max_km": 0}, {"max_km": -5}])
    def test_invalid_charity(self, make_charity, kwargs):
        with pytest.raises(ValidationError):
            make_charity(**kwargs)

    def test_charity_roundtrip(self, make_charity):
        c = make_charity(categories=[FoodCategory.PRODUCE, FoodCategory.DAIRY])
        assert Charity.from_dict(c.to_dict()) == c

    def test_allocation_roundtrip(self, now):
        a = Allocation("F-1", "C-1", 5, 1.5, 0.8, now)
        assert Allocation.from_dict(a.to_dict()) == a
        with pytest.raises(ValidationError):
            Allocation("F-1", "C-1", 0, 1.5, 0.8, now)


class TestGeo:
    def test_known_distance(self):
        nyc, la = Location(40.7128, -74.0060), Location(34.0522, -118.2437)
        assert haversine_km(nyc, la) == pytest.approx(3936, rel=0.01)

    def test_zero_and_symmetry(self):
        a, b = Location(10, 10), Location(11, 12)
        assert haversine_km(a, a) == 0
        assert haversine_km(a, b) == pytest.approx(haversine_km(b, a))

    def test_travel_minutes(self):
        assert estimate_travel_minutes(30, 30) == pytest.approx(60)
        with pytest.raises(ValueError):
            estimate_travel_minutes(1, 0)
