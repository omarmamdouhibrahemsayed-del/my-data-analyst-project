from datetime import timedelta

import pytest

from foodshare.errors import NotFoundError, ValidationError
from foodshare.models import AllocationStatus, DonorType, FoodCategory, ItemStatus, Location
from conftest import FAR, NEAR, NOW


@pytest.fixture
def world(coordinator):
    donor = coordinator.register_donor("Bistro", DonorType.RESTAURANT, Location(*(40.0, -74.0)))
    charity = coordinator.register_charity("Kitchen", Location(*NEAR), 50)
    item = coordinator.post_food(donor.id, "Soup", FoodCategory.PREPARED, 30, NOW + timedelta(hours=3))
    return coordinator, donor, charity, item


def test_post_food_defaults_pickup_to_donor_location(world):
    _, donor, _, item = world
    assert item.pickup_location == donor.location


def test_post_food_validation(coordinator):
    donor = coordinator.register_donor("A", DonorType.OTHER, Location(0, 0))
    with pytest.raises(ValidationError):
        coordinator.post_food(donor.id, "Old", FoodCategory.OTHER, 5, NOW - timedelta(hours=1))
    with pytest.raises(ValidationError):
        coordinator.post_food(donor.id, "Zero", FoodCategory.OTHER, 0, NOW + timedelta(hours=1))
    with pytest.raises(NotFoundError):
        coordinator.post_food("D-missing", "X", FoodCategory.OTHER, 1, NOW + timedelta(hours=1))


def test_run_matching_updates_state(world):
    coord, _, charity, item = world
    result = coord.run_matching()
    assert result.total_portions == 30
    assert item.remaining == 0 and item.status is ItemStatus.ALLOCATED
    assert charity.needed == 20
    assert len(coord.store.allocations) == 1


def test_rerunning_matching_does_not_double_allocate(world):
    coord, *_ = world
    coord.run_matching()
    again = coord.run_matching()
    assert again.allocations == [] and len(coord.store.allocations) == 1


def test_cancel_restores_quantities_and_allows_rematch(world):
    coord, _, charity, item = world
    alloc = coord.run_matching().allocations[0]
    coord.cancel_allocation(alloc.id)
    assert alloc.status is AllocationStatus.CANCELLED
    assert item.remaining == 30 and item.status is ItemStatus.AVAILABLE
    assert charity.needed == 50
    assert coord.run_matching().total_portions == 30


def test_complete_and_state_guards(world):
    coord, *_ = world
    alloc = coord.run_matching().allocations[0]
    coord.complete_allocation(alloc.id)
    assert coord.stats()["portions_delivered"] == 30
    with pytest.raises(ValidationError):
        coord.cancel_allocation(alloc.id)
    with pytest.raises(ValidationError):
        coord.complete_allocation(alloc.id)
    with pytest.raises(NotFoundError):
        coord.complete_allocation("A-missing")


def test_expiry_is_detected_when_clock_advances(world):
    coord, _, _, item = world
    coord.clock = lambda: NOW + timedelta(hours=5)
    assert coord.expire_items() == 1
    assert item.status is ItemStatus.EXPIRED
    assert coord.available_items() == []


def test_update_charity_need(world):
    coord, _, charity, _ = world
    coord.update_charity_need(charity.id, 7)
    assert charity.needed == 7
    with pytest.raises(ValidationError):
        coord.update_charity_need(charity.id, -1)


def test_charity_far_away_is_not_used(coordinator):
    donor = coordinator.register_donor("A", DonorType.OTHER, Location(40.0, -74.0))
    coordinator.register_charity("Far", Location(*FAR), 10, max_distance_km=5)
    coordinator.post_food(donor.id, "Rice", FoodCategory.PACKAGED, 10, NOW + timedelta(hours=8))
    assert coordinator.run_matching().allocations == []
