import json

import pytest

from foodshare.errors import NotFoundError, StorageError, ValidationError
from foodshare.models import Donor, DonorType, Location
from foodshare.service import Coordinator
from foodshare.storage import DataStore
from conftest import NOW


def _populated(path, make_item, make_charity):
    store = DataStore(path)
    donor = store.add_donor(Donor("Cafe", DonorType.RESTAURANT, Location(40, -74)))
    item = make_item()
    item.donor_id = donor.id
    store.add_item(item)
    store.add_charity(make_charity())
    return store


def test_save_and_load_roundtrip(tmp_path, make_item, make_charity):
    path = tmp_path / "data.json"
    coord = Coordinator(_populated(path, make_item, make_charity), clock=lambda: NOW)
    coord.run_matching()  # persists allocations too
    loaded = DataStore.load(path)
    assert loaded.to_dict() == coord.store.to_dict()
    assert len(loaded.allocations) == 1


def test_missing_file_gives_empty_store(tmp_path):
    store = DataStore.load(tmp_path / "nope.json")
    assert store.donors == {} and store.items == {}


def test_empty_file_gives_empty_store(tmp_path):
    p = tmp_path / "empty.json"
    p.write_text("")
    assert DataStore.load(p).charities == {}


@pytest.mark.parametrize(
    "content",
    ["{not json", "[]", json.dumps({"schema_version": 99}),
     json.dumps({"schema_version": 1, "donors": [{"id": "D-1"}], "charities": [], "items": [], "allocations": []})],
)
def test_corrupt_or_invalid_files_raise_storage_error(tmp_path, content):
    p = tmp_path / "bad.json"
    p.write_text(content)
    with pytest.raises(StorageError):
        DataStore.load(p)


def test_broken_reference_detected(tmp_path, make_item, make_charity):
    data = _populated(None, make_item, make_charity).to_dict()
    data["items"][0]["donor_id"] = "D-missing"
    p = tmp_path / "bad.json"
    p.write_text(json.dumps(data))
    with pytest.raises(StorageError):
        DataStore.load(p)


def test_save_is_atomic_and_leaves_no_temp_file(tmp_path):
    p = tmp_path / "sub" / "data.json"
    store = DataStore(p)
    store.add_donor(Donor("A", DonorType.OTHER, Location(0, 0)))
    store.save()
    assert p.exists() and [f.name for f in p.parent.iterdir()] == ["data.json"]


def test_unwritable_path_raises_storage_error(tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    store = DataStore(blocker / "data.json")  # parent is a file
    with pytest.raises(StorageError):
        store.save()


def test_integrity_checks(make_item):
    store = DataStore()
    with pytest.raises(NotFoundError):
        store.add_item(make_item())  # donor D-1 does not exist
    donor = store.add_donor(Donor("A", DonorType.OTHER, Location(0, 0)))
    with pytest.raises(ValidationError):
        store.add_donor(donor)  # duplicate id
    with pytest.raises(NotFoundError):
        store.get_charity("C-nope")
