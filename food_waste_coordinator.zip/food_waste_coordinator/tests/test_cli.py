from datetime import timedelta

import pytest

from foodshare.cli import App, Prompter, format_table, format_timedelta, main
from foodshare.errors import ValidationError
from foodshare.parsing import (
    parse_expiry, parse_index_list, parse_int, parse_location, parse_positive_float,
)
from foodshare.storage import DataStore
from conftest import NOW


class TestParsing:
    @pytest.mark.parametrize(
        "text,delta",
        [("2h", timedelta(hours=2)), ("90m", timedelta(minutes=90)), ("1h30m", timedelta(hours=1, minutes=30)),
         ("1.5 hours", timedelta(hours=1.5)), ("45 min", timedelta(minutes=45))],
    )
    def test_expiry_durations(self, text, delta):
        assert parse_expiry(text, NOW) == NOW + delta

    def test_expiry_absolute(self):
        assert parse_expiry("2030-05-01 18:30", NOW).year == 2030

    @pytest.mark.parametrize("text", ["", "soon", "0h", "5", "2x"])
    def test_expiry_invalid(self, text):
        with pytest.raises(ValidationError):
            parse_expiry(text, NOW)

    def test_location(self):
        loc = parse_location("40.7, -74.0")
        assert (loc.lat, loc.lon) == (40.7, -74.0)
        for bad in ("", "40.7", "a, b", "95, 0", "1, 2, 3"):
            with pytest.raises(ValidationError):
                parse_location(bad)

    def test_numbers(self):
        assert parse_int(" 5 ", 1, 10) == 5
        for bad in ("x", "0", "11", ""):
            with pytest.raises(ValidationError):
                parse_int(bad, 1, 10)
        assert parse_positive_float("2.5") == 2.5
        for bad in ("0", "-1", "abc", "inf"):
            with pytest.raises(ValidationError):
                parse_positive_float(bad)

    def test_index_list(self):
        assert parse_index_list("3, 1 ,3", 5) == [1, 3]
        assert parse_index_list("", 5) == []
        with pytest.raises(ValidationError):
            parse_index_list("9", 5)


def test_formatting_helpers():
    table = format_table(["A", "Long"], [["x", "y"], ["wide cell", "z"]])
    assert table.splitlines()[0].startswith("A") and "wide cell" in table
    assert format_timedelta(timedelta(hours=2, minutes=5)) == "2h 05m"
    assert format_timedelta(timedelta(minutes=7)) == "7m"
    assert format_timedelta(timedelta(minutes=-1)) == "expired"


def _run_app(coordinator, inputs):
    out = []
    feed = iter(inputs)
    app = App(coordinator, Prompter(lambda _prompt: next(feed), out.append))
    code = app.run()  # StopIteration is not caught, so scripts must end with "0"
    return code, "\n".join(out)


def test_full_workflow_with_invalid_input_recovery(coordinator):
    code, out = _run_app(coordinator, [
        "99",                                                   # invalid menu choice
        "2",                                                    # post food before any donor exists
        "1", "Green Bistro", "1", "555-0101", "40.0, -74.0", "Main St",
        "3", "Hope Kitchen", "", "40.01, -74.0", "Elm St", "50", "", "",
        "2", "1", "Lasagna", "1", "abc", "20", "later", "4h", "",   # bad quantity, bad expiry
        "4", "5", "6", "7", "0",
    ])
    assert code == 0
    assert "Invalid option" in out
    assert "register a donor first" in out
    assert "is not a whole number" in out and "Could not understand that time" in out
    assert "Created 1 allocation(s) covering 20 portion(s)" in out
    assert "Lasagna" in out and "Hope Kitchen" in out and "Totals:" in out
    assert len(coordinator.store.allocations) == 1


def test_demo_data_and_matching(coordinator):
    code, out = _run_app(coordinator, ["10", "6", "7", "0"])
    assert code == 0 and "Demo data loaded" in out
    assert len(coordinator.store.allocations) > 0


def test_cancel_allocation_via_menu(coordinator):
    _run_app(coordinator, ["10", "6", "8", "1", "2", "0"])
    statuses = {a.status.value for a in coordinator.store.allocations.values()}
    assert "cancelled" in statuses


def test_eof_exits_gracefully(coordinator):
    def raise_eof(_):
        raise EOFError
    assert App(coordinator, Prompter(raise_eof, lambda _: None)).run() == 0


def test_main_reports_corrupt_data_file(tmp_path, capsys):
    bad = tmp_path / "bad.json"
    bad.write_text("{oops")
    assert main(["--data", str(bad)]) == 2
    assert "not valid JSON" in capsys.readouterr().err
