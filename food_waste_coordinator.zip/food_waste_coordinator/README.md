# Smart Food Waste & Donation Coordinator

A menu-driven CLI that connects food donors (restaurants, events, groceries,
individuals) with charities, and automatically matches surplus food to the most
suitable recipient based on **distance, expiry urgency and quantity**.

* Pure standard library at runtime (Python 3.9+), `pytest` for tests only.
* State is stored in a single JSON file, written atomically.

## Setup

```bash
# 1. (optional) create a virtual environment
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate

# 2. install (editable) with the test dependency
pip install -e ".[dev]"              # or: pip install -r requirements.txt

# 3. run the app
foodshare                            # console script, or:
python -m foodshare --data my_data.json

# 4. run the tests
pytest -q
```

Tip: choose **10. Load demo data** and then **6. Run matching algorithm** for an
instant walkthrough.

## Using the CLI

| Option | What it does |
|-------:|--------------|
| 1 | Register a donor (name, type, contact, `lat, lon`) |
| 2 | Post surplus food (category, portions, expiry like `2h`, `90m`, `1h30m` or `2026-03-01 18:30`) |
| 3 | Register a charity (portions needed, accepted categories, max pickup distance) |
| 4 / 5 | List available food / charities |
| 6 | Run the matching algorithm |
| 7 | View the distribution log with totals |
| 8 | Mark a scheduled allocation completed, or cancel it (portions return to the pool) |
| 9 | Update a charity's current need (needs shrink as food is allocated) |
| 10 | Load demo data |

Invalid input never crashes the app: bad values are explained and re-prompted;
a corrupt data file is reported with exit code 2; Ctrl-C / Ctrl-D exit cleanly.

## Matching algorithm (`foodshare/matching.py`)

1. Items are processed **soonest-expiring first** (ties: larger batch first).
2. Hard filters per charity: accepts the category, has unmet need, within its
   own max distance, and can **reach the pickup before expiry**
   (travel at 30 km/h + 15 min handling buffer).
3. Remaining candidates are scored in `[0, 1]`:

   ```
   proximity = 1 - distance / charity.max_distance
   fit       = min(remaining, need) / max(remaining, need)
   urgency   = 1 - clamp(hours_left / 24)
   score     = ((0.5 + 0.2*urgency) * proximity + 0.3 * fit) / 1.0
   ```
   Urgent food weights proximity more; `fit` favours charities whose need
   matches the batch and avoids fragmenting donations.
4. The best charity gets `min(remaining, need)`; large donations are split
   across several charities until exhausted or no one qualifies.

The matcher is a pure function (inputs are never mutated) and deterministic.
All weights and speeds live in `MatchConfig` and can be tuned.

## Project layout

```
foodshare/
  errors.py     exception hierarchy (ValidationError, NotFoundError, StorageError)
  models.py     Location, Donor, FoodItem, Charity, Allocation (+ validation, (de)serialisation)
  geo.py        haversine distance, travel-time estimate
  matching.py   MatchConfig, scoring, match() -> MatchResult
  storage.py    DataStore: in-memory collections + atomic JSON persistence
  service.py    Coordinator: business rules (post, match, complete, cancel, stats)
  parsing.py    pure input parsers (durations, coordinates, numbers)
  cli.py        Prompter + App (menu) + main()
  demo.py       sample data
tests/          pytest suite (models, geo, matching, storage, service, CLI)
```

## Extending

* **GUI / web API:** `Coordinator` is UI-agnostic; build on top of it.
* **Real road distances:** replace `haversine_km` in `matching.py` with a
  routing-API call (keep the signature).
* **Dietary / halal / allergen tags:** add a field to `FoodItem` and a
  filter in the hard-constraint step of `match()`.
